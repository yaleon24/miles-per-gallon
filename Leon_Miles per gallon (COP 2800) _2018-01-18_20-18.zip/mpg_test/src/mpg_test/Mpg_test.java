
//package mpg_test;

/*
Before submitting your project, delete the line above:
package mpg_test
 */


import java.util.Scanner;

/**
 *
 * @author Yasmany Leon
 */
public class Mpg_test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scanner= new Scanner(System.in);
        double total;
        double miles=scanner.nextDouble();
        double galones=scanner.nextDouble();
        total=miles/galones;
        if(galones==0){
            System.out.print("Can not calculate.");
            
        }
        else{
            
            System.out.print(total);
        }
    }
    
}
